function nullS = nullspaceLUSOLform(S)

%        nullS = nullspaceLUSOLform(S);
% computes a structure nullS from which
%        W = nullspaceLUSOLapply(nullS,V);
% can compute W from matrix V such that S*W = 0.
%
% We assume S is m x n with m < n.
% nullS.rank returns the rank of S (rank <= m).
% It doesn't matter if rank < m.
%
% REQUIRED: lusolSet.m and lusolFactor.m (which calls the LUSOL mex-file).

% 02 May 2008: (MAS) First version of nullspaceLUSOLform.m.
%              load iCore_stoich_mu_Stanford.mat   % loads a matrix A;
%              nullS = nullspaceLUSOLform(A);      % forms Z.

[m,n] = size(S);
fprintf('\nsize(S) = %10g x %10g', m,n)

if m >= n
  fprintf('\nS must have fewer rows than columns\n')
  return
end

if ~issparse(S)
  disp('Converting dense S to sparse(S)')
  S = sparse(S);
end

fprintf('\n nnz(S) = %10g\n\n', nnz(S))

%%%%%%% Scale S
  tic
  iprint  = 1;
  scltol  = 0.9;
  [cscale,rscale] = gmscal(S,iprint,scltol);

  C = spdiags(cscale,0,n,n);   Cinv = spdiags(1./cscale,0,n,n);
  R = spdiags(rscale,0,m,m);   Rinv = spdiags(1./rscale,0,m,m);
  A = Rinv*S*Cinv;
  toc

%%%%%%% Factorize A = the scaled S
  tic
  options = lusolSet;
  options.Pivoting  = 'TRP';
  options.FactorTol = 1.5;

  [L,U,p,q,options] = lusolFactor(A',options);   % Note A'
  rankS = options.Rank;
  L     = L(p,p);      % New L is strictly lower triangular (and square).
% U     = U(p,q);      % New U would be upper trapezoidal the size of S'.
  toc


% P*S'(:,q) = L*U means inv(L)*P*S'*Q = U, where Q is the perm from q
% and the bottom rows of U are zero: U(rank+1:n,:) = 0.
% This means (Q'*S*P')*inv(L') = U'   has its last columns = 0.
% Hence,         S*(P'*inv(L') = Q*U' has its last columns = 0.
% Q has no effect.
% Hence the null space of S is Z = the last cols of P'*inv(L'):
% When S is scaled as S = R*A*C, we have Z = Cinv*P'*inv(L')[0;I].

  nullS.Cinv = Cinv;
  nullS.L    = L;
  nullS.p    = p;
  nullS.rank = rankS;

  fprintf('\nrank(S) = %10g', rankS)
  fprintf('\nnnz(L)  = %10g', nnz(L))
  fprintf('\nnnz(U)  = %10g', nnz(U))
  fprintf('\nnull(S) is represented by L, permutation p, and column scaling Cinv\n\n')
  return
