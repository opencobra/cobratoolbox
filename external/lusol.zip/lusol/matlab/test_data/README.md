## LUSOL test matrices

These matrices come from [The University of Florida Sparse Matrix Collection][UFSMC].

  [UFSMC]: http://www.cise.ufl.edu/research/sparse/matrices/
